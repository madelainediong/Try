package com.example.asus.canteensurvey;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

public class SurveyActivity extends AppCompatActivity {

    String nameInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_survey);



    }
}
